<?php

namespace App\Controllers;

require_once APPPATH . 'ThirdParty/Mg3lo/vendor/autoload.php';

use Mg3lo\MySqlCrudApi;

class Crud extends BaseController
{
    public function index()
    {
        // connect to your mysql database
		$api = new MySqlCrudApi([
			'username' => 'root',
			'password' => '',
			'database' => 'my_database'
		]);
		
		// let the library manage all api calls
		$api->manage(); 
    }
}
