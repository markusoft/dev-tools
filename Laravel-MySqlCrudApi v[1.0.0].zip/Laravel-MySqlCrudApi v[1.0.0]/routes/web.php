<?php

use Illuminate\Support\Facades\Route;

use Mg3lo\MySqlCrudApi;

// connect to your database
$api = new MySqlCrudApi([
  'username' => 'root',
  'password' => '',
  'database' => 'play_around'
]);

// catch all routes entering http://your-website/crud/
Route::any('{crud}', function ($any) use ($api) {

		// manage all calls
		$api->manage();
	
})->where('crud', '.*crud.*');

