1. Copy folder on your server e.g. xampp/htdocs
2. Enjoy!

C-reate  POST http://your-website.com/{route}/{database-table-name}
R-ead    GET http://your-website.com/{route}/{database-table-name}/{id}/{related-table-name}/{id}?{parameter}={value}
U-pdate  PUT|PATCH http://your-website.com/{route}/{database-table-name}/{id}
D-elete  DELETE http://your-website.com/{route}/{database-table-name}/{id}

Description 		HTTP Verb 	URL
All Records		GET 		http://your-website.com/crud/products
Record ID 		GET 		http://your-website.com/crud/products/1
Filtered Records 	GET 		http://your-website.com/crud/products?status=active
Search Records 		GET 		http://your-website.com/crud/products?search=iphone
Pagination 		GET 		http://your-website.com/crud/products?limit=100&offset=100
Sort and Order 		GET 		http://your-website.com/crud/products?sort=price&order=asc
Child Records 		GET 		http://your-website.com/crud/categories/1/products
Related Records 	GET 		http://your-website.com/crud/categories?with=products
Add Record/s 		POST 		http://your-website.com/crud/products
Add Related Records 	POST 		http://your-website.com/crud/categories?with=product
Update a Record 	POST 		http://your-website.com/crud/products/1
Update Records 		POST 		http://your-website.com/crud/products
Delete a Record 	DELETE 		http://your-website.com/crud/products/1
Delete Records 		DELETE 		http://your-website.com/crud/products