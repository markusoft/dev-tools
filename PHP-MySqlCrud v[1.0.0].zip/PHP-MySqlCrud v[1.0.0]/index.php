<?php
// Loads the library
require_once './Mg3lo/vendor/autoload.php'; 

use Mg3lo\MySqlCrud;

// connect to your database
$crud = new MySqlCrud([
	'username' => 'root',
	'password' => '',
	'database' => 'my_database'
]);

// do your magic
$products = $crud->table('products')
				->where('price', '<', 1000)
				->get();
				
print_r($products);