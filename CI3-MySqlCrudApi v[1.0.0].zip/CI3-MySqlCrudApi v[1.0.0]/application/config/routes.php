<?php

// catch all routes going to crud http://localhost/yourwebsite/crud/?
$route['crud/(:any)'] = 'crud';
$route['crud/(:any)/(:any)'] = 'crud';
$route['crud/(:any)/(:any)/(:any)'] = 'crud';
$route['crud/(:any)/(:any)/(:any)/(:any)'] = 'crud';