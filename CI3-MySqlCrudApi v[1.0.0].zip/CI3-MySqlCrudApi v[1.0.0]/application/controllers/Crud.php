<?php
defined('BASEPATH') OR exit('No direct script access allowed');

// Loads the library
require_once APPPATH . 'third_party/Mg3lo/vendor/autoload.php';

use Mg3lo\MySqlCrudApi;

class Crud extends CI_Controller {

	public function index()
	{
		// connect to your mysql database
		$api = new MySqlCrudApi([
			'username' => 'root',
			'password' => '',
			'database' => 'my_database'
		]);
		
		// let the library manage all api calls
		$api->manage(); 
	}
}
