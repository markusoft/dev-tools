<?php

namespace App\Controllers;

require_once APPPATH . 'ThirdParty/Mg3lo/vendor/autoload.php';

use Mg3lo\MySqlCrud;

class Crud extends BaseController
{
    public function index()
    {
        // connect to your mysql database
		$crud = new MySqlCrud([
			'username' => 'root',
			'password' => '',
			'database' => 'my_database'
		]);
		
		// do your magic
		$products = $crud->table('products')
						->where('price', '<', 1000)
						->get();
    }
}
