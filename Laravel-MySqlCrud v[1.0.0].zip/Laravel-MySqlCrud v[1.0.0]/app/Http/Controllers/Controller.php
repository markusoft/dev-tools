<?php

namespace App\Http\Controllers;

// load the library if you did not install it via composer
require_once app_path('Mg3lo/vendor/autoload.php');

use Mg3lo\MySqlCrud;

class Controller extends BaseController
{
	public function query()
	{
		// connect to your mysql database
		$crud = new MySqlCrud([
			'host' => env(DB_HOST),
			'username' => env(DB_USERNAME),
			'password' => env(DB_PASSWORD),
			'database' => env(DB_DATABASE),
		]);
		
		// do your magic
		$products = $crud->table('products')
						->where('price', '<', 1000)
						->get();
	}
}
