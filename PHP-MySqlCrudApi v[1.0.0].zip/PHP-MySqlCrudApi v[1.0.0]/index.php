<?php
// Loads the library
require_once './Mg3lo/vendor/autoload.php'; 

use Mg3lo\MySqlCrud; // mysql crud
use Mg3lo\MySqlCrudApi; // mysql crud api

// connect to your database
$crud = new MySqlCrud([
	'username' => 'root',
	'password' => '',
	'database' => 'my_database'
]);

// sample query to retrieve all products from your database
/*
$products = $crud
	->table('products')
	->get();
print_r($products); 
*/



// connect to your database
$api = new MySqlCrudApi([
	'username' => 'root',
	'password' => '',
	'database' => 'my_database'
]);

// manage all calls
$api->manage();

// try http://localhost/{folder_name}/crud/{table_name}
// e.g. http://localhost/mysite/crud/products