<?php
defined('BASEPATH') OR exit('No direct script access allowed');

// Loads the library
require_once APPPATH . 'third_party/Mg3lo/vendor/autoload.php';

use Mg3lo\MySqlCrud;

class Crud extends CI_Controller {

	public function index()
	{
		// connect to your mysql database
		$crud = new MySqlCrud([
			'username' => 'root',
			'password' => '',
			'database' => 'my_database'
		]);
		
		// do your magic
		$products = $crud->table('products')
						->where('price', '<', 1000)
						->get();
	}
}
