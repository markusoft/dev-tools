1. Update or copy files according to their folder structure on your codeigniter installation folder
2. Enjoy!